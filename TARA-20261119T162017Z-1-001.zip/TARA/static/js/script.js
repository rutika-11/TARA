// TARA - front-end interactions (vanilla JS, no frameworks)

document.addEventListener("DOMContentLoaded", function () {
    // Mobile nav toggle
    var toggle = document.querySelector(".mobile-toggle");
    var nav = document.querySelector(".main-nav");
    if (toggle && nav) {
        toggle.addEventListener("click", function () {
            nav.classList.toggle("open");
        });
    }

    // Auto-hide flash alerts after a few seconds
    document.querySelectorAll(".alert").forEach(function (el) {
        setTimeout(function () {
            el.style.transition = "opacity .4s";
            el.style.opacity = "0";
            setTimeout(function () { el.remove(); }, 400);
        }, 3500);
    });

    // Quantity selector on product detail page
    var qtyInput = document.getElementById("qty-input");
    var qtyMinus = document.getElementById("qty-minus");
    var qtyPlus = document.getElementById("qty-plus");
    if (qtyInput && qtyMinus && qtyPlus) {
        qtyMinus.addEventListener("click", function () {
            var val = parseInt(qtyInput.value || "1", 10);
            if (val > 1) qtyInput.value = val - 1;
        });
        qtyPlus.addEventListener("click", function () {
            var val = parseInt(qtyInput.value || "1", 10);
            qtyInput.value = val + 1;
        });
    }

    // Security lab tab switching (pure UI, server still renders both panels)
    document.querySelectorAll("[data-lab-tab]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var target = btn.getAttribute("data-lab-tab");
            document.querySelectorAll(".lab-tab-panel").forEach(function (p) {
                p.style.display = p.id === target ? "block" : "none";
            });
        });
    });
});
