"""
TARA - Database Initialization Script
--------------------------------------
Creates database/database.db (SQLite) with all required tables and seeds
sample data (users, products, reviews, orders) so the app works immediately
after cloning.

Run automatically by app.py on first launch, or manually with:
    python database/init_db.py

NOTE ON THE SECURITY DEMONSTRATIONS
------------------------------------
This version has NO separate "security lab" tables. The three academic
vulnerabilities (SQL Injection, XSS, Broken Authentication) live inside the
*real* login and product-review features, toggled by the LAB_MODE setting
in app.py. There is nothing to seed here for them beyond the normal
`users` and `reviews` tables already used by the live shop.
"""

import sqlite3
import os
from werkzeug.security import generate_password_hash

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "database.db")


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    password_plain TEXT,        -- NULL in secure use; see app.py LAB_MODE
    is_admin INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    collection TEXT,
    price REAL NOT NULL,
    description TEXT,
    material TEXT,
    image TEXT,
    rating REAL DEFAULT 4.5,
    is_new INTEGER DEFAULT 0,
    is_bestseller INTEGER DEFAULT 0,
    stock INTEGER DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    user_name TEXT NOT NULL,
    rating INTEGER DEFAULT 5,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS wishlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id),
    UNIQUE(user_id, product_id)
);

CREATE TABLE IF NOT EXISTS cart_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    total REAL NOT NULL,
    status TEXT DEFAULT 'Placed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);
"""


def init_db(force=False):
    """Create the database and seed it with sample data if it doesn't exist."""
    first_time = not os.path.exists(DB_PATH) or force

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.executescript(SCHEMA)
    conn.commit()

    # Only seed if the products table is empty (keeps re-runs idempotent)
    cur.execute("SELECT COUNT(*) FROM products")
    if cur.fetchone()[0] == 0:
        seed(cur)
        conn.commit()

    conn.close()
    return first_time


def seed(cur):
    # ---------------- Users ----------------
    # Passwords are ALWAYS stored hashed (password_hash), in every mode.
    # password_plain is populated ONLY for these two well-known, already
    # publicly-documented demo accounts, purely so the login vulnerability
    # demo (app.py, LAB_MODE="vulnerable") has real data to compare
    # against out of the box. Accounts a real user registers afterwards
    # only get a password_plain value if LAB_MODE was "vulnerable" at the
    # moment they registered (see the /register route in app.py) — never
    # by default.
    demo_users = [
        ("Admin User", "admin@tara.local", "Admin@123", 1),
        ("Demo Customer", "customer@tara.local", "Customer@123", 0),
    ]
    for name, email, pwd, is_admin in demo_users:
        cur.execute(
            """INSERT OR IGNORE INTO users (name, email, password_hash, password_plain, is_admin)
               VALUES (?, ?, ?, ?, ?)""",
            (name, email, generate_password_hash(pwd), pwd, is_admin),
        )

    # ---------------- Products (30 items across 6 categories) ----------------
    # image paths are relative to static/images/products/
    products = [
        # ---- Earrings (6) ----
        ("Tiny Gold Hoops", "Earrings", "College Edit", 399,
         "Lightweight everyday hoops that go with everything, from lectures to late-night plans.",
         "Gold-plated brass", "hoops.jpeg", 4.6, 1, 1),
        ("Pearl Studs", "Earrings", "Everyday Essentials", 449,
         "Classic pearl studs for a soft, polished look — perfect for daily wear.",
         "Freshwater pearl, silver post", "pearl_studs.jpeg", 4.7, 0, 1),
        ("Office Edit Earrings", "Earrings", "Work Edit", 499,
         "Understated studs designed to look sharp in every meeting.",
         "Gold-plated brass", "office_earrings.jpeg", 4.4, 1, 0),
        ("Minimal Drop Earrings", "Earrings", "Minimal Classics", 549,
         "Subtle drop earrings that add a little movement without being loud.",
         "Gold-plated brass", "drop_earrings.jpeg", 4.3, 0, 0),
        ("Classic Gold Hoops", "Earrings", "Everyday Essentials", 599,
         "A slightly bolder hoop for when you want a touch more presence.",
         "Gold-plated brass", "classic_hoops.jpeg", 4.5, 0, 1),
        ("College Edit Studs", "Earrings", "College Edit", 399,
         "Fun, tiny studs designed for everyday college styling.",
         "Gold-plated brass", "college_studs.jpeg", 4.2, 1, 0),

        # ---- Rings (5) ----
        ("Everyday Ring", "Rings", "Everyday Essentials", 399,
         "A comfortable, stackable ring for daily wear at college or work.",
         "Gold-plated brass", "ring.jpeg", 4.3, 0, 0),
        ("Minimal Band Ring", "Rings", "Minimal Classics", 449,
         "A clean, thin band that pairs well with everything else you wear.",
         "Gold-plated brass", "band_ring.jpeg", 4.2, 0, 0),
        ("Pearl Ring", "Rings", "Gifting", 599,
         "A single freshwater pearl set on a delicate gold-plated band.",
         "Freshwater pearl, gold-plated brass", "pearl_ring.jpeg", 4.6, 0, 0),
        ("Classic Stack Ring", "Rings", "Work Edit", 499,
         "A set of three thin bands designed to be stacked or worn alone.",
         "Gold-plated brass", "stack_ring.jpeg", 4.4, 0, 1),
        ("Dainty Gold Ring", "Rings", "College Edit", 399,
         "A featherweight ring for everyday college styling.",
         "Gold-plated brass", "dainty_ring.jpeg", 4.1, 1, 0),

        # ---- Necklaces (5) ----
        ("Minimal Chain Necklace", "Necklaces", "Minimal Classics", 649,
         "A slim, minimal chain necklace designed for everyday layering.",
         "Gold-plated brass", "chain_necklace.jpeg", 4.4, 1, 0),
        ("Small Pearl Necklace", "Necklaces", "Gifting", 699,
         "A delicate pearl necklace that makes a thoughtful, affordable gift.",
         "Freshwater pearl, gold-plated chain", "pearl_necklace.jpeg", 4.8, 0, 1),
        ("Layering Necklace", "Necklaces", "Minimal Classics", 599,
         "A fine chain built for layering with your other everyday pieces.",
         "Gold-plated brass", "layering_chain.jpeg", 4.3, 1, 0),
        ("Delicate Bar Necklace", "Necklaces", "Work Edit", 599,
         "A slim horizontal bar on a fine chain — quiet and polished for the office.",
         "Gold-plated brass", "bar_necklace.jpeg", 4.3, 0, 0),
        ("Everyday Gold Necklace", "Necklaces", "Everyday Essentials", 649,
         "A simple gold chain that works on its own or layered underneath.",
         "Gold-plated brass", "gold_necklace.jpeg", 4.5, 0, 0),

        # ---- Pendants (5) ----
        ("Dainty Pendant", "Pendants", "Minimal Classics", 599,
         "A delicate pendant necklace that layers beautifully or stands alone.",
         "Gold-plated brass", "pendant.jpeg", 4.5, 0, 0),
        ("Everyday Pendant", "Pendants", "Everyday Essentials", 549,
         "A simple circular pendant designed for daily wear.",
         "Gold-plated brass", "everyday_pendant.jpeg", 4.3, 0, 0),
        ("Classic Pendant", "Pendants", "Gifting", 649,
         "A faceted pendant with a soft shimmer, gift-box ready.",
         "Gold-plated brass", "classic_pendant.jpeg", 4.6, 0, 0),
        ("Heart Pendant", "Pendants", "Gifting", 599,
         "A soft heart-shaped pendant, a simple everyday token of affection.",
         "Gold-plated brass", "heart_pendant.jpeg", 4.7, 0, 1),
        ("Initial Pendant", "Pendants", "College Edit", 499,
         "A personal, monogram-inspired pendant for a personal touch.",
         "Gold-plated brass", "initial_pendant.jpeg", 4.4, 1, 0),

        # ---- Bracelets (5) ----
        ("Slim Chain Bracelet", "Bracelets", "Work Edit", 449,
         "A slim, understated bracelet that fits neatly under a shirt sleeve.",
         "Gold-plated brass", "bracelet.jpeg", 4.5, 0, 0),
        ("Pearl Bracelet", "Bracelets", "Gifting", 549,
         "A row of freshwater pearls on a delicate gold-plated chain.",
         "Freshwater pearl, gold-plated brass", "pearl_bracelet.jpeg", 4.6, 0, 0),
        ("Minimal Bracelet", "Bracelets", "Minimal Classics", 399,
         "The simplest possible bracelet, made to be worn every single day.",
         "Gold-plated brass", "minimal_bracelet.jpeg", 4.2, 0, 0),
        ("Classic Bangle", "Bracelets", "Everyday Essentials", 549,
         "A simple, sturdy bangle for everyday stacking.",
         "Gold-plated brass", "bangle.jpeg", 4.1, 0, 0),
        ("Beaded Bracelet", "Bracelets", "College Edit", 399,
         "A playful mix of beads for a fun, everyday college look.",
         "Gold-plated brass, glass beads", "beaded_bracelet.jpeg", 4.3, 1, 0),

        # ---- Jewelry Sets (4) ----
        ("Classic Gift Set", "Jewelry Sets", "Gifting", 899,
         "A matching earring-and-pendant set, gift-boxed and ready to give.",
         "Gold-plated brass", "gift_set.jpeg", 4.9, 0, 1),
        ("Everyday Jewelry Set", "Jewelry Sets", "Everyday Essentials", 799,
         "A matching earring-and-bracelet set for effortless everyday styling.",
         "Gold-plated brass", "everyday_set.jpeg", 4.5, 0, 0),
        ("Pearl Gift Set", "Jewelry Sets", "Gifting", 899,
         "Pearl studs and a matching pendant, presented gift-box ready.",
         "Freshwater pearl, gold-plated brass", "pearl_set.jpeg", 4.8, 0, 1),
        ("Minimal Matching Set", "Jewelry Sets", "Minimal Classics", 749,
         "A ring and necklace designed to be worn together or separately.",
         "Gold-plated brass", "minimal_set.jpeg", 4.4, 0, 0),
    ]
    for p in products:
        cur.execute(
            """INSERT INTO products
               (name, category, collection, price, description, material, image, rating, is_new, is_bestseller)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            p,
        )

    # ---------------- Reviews ----------------
    reviews = [
        (1, "Ananya", 5, "Perfect for everyday college wear, super lightweight!"),
        (1, "Priya", 4, "Lovely hoops, exactly as pictured."),
        (2, "Sneha", 5, "The pearl studs are so elegant, wear them to work daily."),
        (13, "Meera", 5, "Bought this as a gift for my sister, she loved it."),
        (27, "Kavya", 5, "Beautiful gift set, great packaging too."),
        (7, "Divya", 4, "Comfortable to wear all day, doesn't irritate my finger."),
        (21, "Isha", 5, "The bracelet is so delicate and pretty, gets compliments often."),
    ]
    for r in reviews:
        cur.execute(
            "INSERT INTO reviews (product_id, user_name, rating, comment) VALUES (?, ?, ?, ?)", r
        )

    # ---------------- Sample Orders ----------------
    cur.execute("SELECT id FROM users WHERE email = 'customer@tara.local'")
    customer_id = cur.fetchone()[0]
    cur.execute(
        "INSERT INTO orders (user_id, total, status) VALUES (?, ?, ?)",
        (customer_id, 848.0, "Delivered"),
    )
    order_id = cur.lastrowid
    cur.execute(
        "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)",
        (order_id, 1, 1, 399.0),
    )
    cur.execute(
        "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)",
        (order_id, 2, 1, 449.0),
    )


if __name__ == "__main__":
    first = init_db(force=True)
    print("Database initialized and seeded at:", DB_PATH)
